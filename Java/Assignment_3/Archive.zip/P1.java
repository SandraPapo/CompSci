import java.util.Scanner;
import java.lang.StringBuilder;

public class P1 {
	public static void main(String[] args) {

		String testValue1 = "4012 8888 8888 1881";
		if (validate(testValue1))
			System.out.println("Card Number: " + testValue1 + " is Valid.");
		else
			System.out.println("Card Number: " + testValue1 + " is Invalid.");

		String testValue2 = "sdafdssad";
		if (validate(testValue2))
			System.out.println("Card Number: " + testValue2 + " is Valid.");
		else
			System.out.println("Card Number: " + testValue2 + " is Invalid.");

		String testValue3 = "12341123123";
		if (validate(testValue3))
			System.out.println("Card Number: " + testValue3 + " is Valid.");
		else
			System.out.println("Card Number: " + testValue3 + " is Invalid.");


	}

	private static boolean validate(String inputNumber) {
		String cardNumber = inputNumber.replaceAll("\\s","");
		// If the card is actually a number...
		try {
			Long.parseLong(cardNumber);
		}
		
		catch(Exception e) {
			return false;
		}

		String reverseCardNumber = new StringBuilder(cardNumber).reverse().toString();
		int oddValue = 0;
		int evenValue = 0;
		int totalValue = 0;
		int digitCount = 0;

		for(int i = 0; i < reverseCardNumber.length(); i++) {
			int currentValue = Character.getNumericValue(reverseCardNumber.charAt(i));
			if ((i % 2) == 0) {
				evenValue += currentValue;
				if ( currentValue > 4)
					digitCount++;
			}
			else
				oddValue += currentValue;
		}
		totalValue =  (evenValue + oddValue) + (oddValue) + (digitCount);

		if ((totalValue % 10) == 0)
			return true;
		else
			return false;

	}
}